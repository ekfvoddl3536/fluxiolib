﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Jobs;
using fluxiolib;
using System.Reflection;

[SimpleJob(RuntimeMoniker.Net80)]
[MarkdownExporter]
public class ReflectionVSFluxIOLib
{
    private FooRoot[] items = [];

    [Params(1, 10, 100, 1_000)]
    public int N;

    private (FieldInfo, FieldInfo, FieldInfo, FieldInfo) cached_FieldInfo;
    private (FluxRuntimeFieldDesc, FluxRuntimeFieldDesc, FluxRuntimeFieldDesc, FluxRuntimeFieldDesc) cached_FieldDesc;

    [GlobalSetup]
    public void Setup()
    {
        items = new FooRoot[N];

        var rand = new Random();
        for (int i = 0; i < items.Length; ++i)
        {
            int v = rand.Next(0, 300);
            items[i] =
                v >= 200
                ? new FooRoot()
                : v >= 100
                ? new FooMid()
                : new FooLast();

            items[i].Rand();
        }

        CacheFieldInfo();
        CacheFieldDesc();
    }

    private void CacheFieldDesc()
    {
        Type t = typeof(FooRoot);

        FluxSearchSpace space = new FluxSearchSpace(3, 4);

        FluxRuntimeFieldDesc fd_x = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space);
        FluxRuntimeFieldDesc fd_y = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space);
        FluxRuntimeFieldDesc fd_z = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space);
        FluxRuntimeFieldDesc fd_w = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space);

        cached_FieldDesc = (fd_x, fd_y, fd_z, fd_w);
    }

    private void CacheFieldInfo()
    {
        const BindingFlags FLAGS = BindingFlags.NonPublic | BindingFlags.Instance;

        Type t = typeof(FooRoot);

        FieldInfo fd_x = t.GetField("vec4_x", FLAGS)!;
        FieldInfo fd_y = t.GetField("vec4_y", FLAGS)!;
        FieldInfo fd_z = t.GetField("vec4_z", FLAGS)!;
        FieldInfo fd_w = t.GetField("vec4_w", FLAGS)!;

        cached_FieldInfo = (fd_x, fd_y, fd_z, fd_w);
    }

    [Benchmark]
    public double ReflectionWithoutCache()
    {
        const BindingFlags FLAGS = BindingFlags.NonPublic | BindingFlags.Instance;

        double sum = 0;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            Type t = vs[i].GetType();
             
            FieldInfo fd_x = t.GetField("vec4_x", FLAGS)!;
            FieldInfo fd_y = t.GetField("vec4_y", FLAGS)!;
            FieldInfo fd_z = t.GetField("vec4_z", FLAGS)!;
            FieldInfo fd_w = t.GetField("vec4_w", FLAGS)!;

            sum += (float)fd_x.GetValue(items[i])!;
            sum += (float)fd_y.GetValue(items[i])!;
            sum += (float)fd_z.GetValue(items[i])!;
            sum += (float)fd_w.GetValue(items[i])!;

            fd_x.SetValue(items[i], -10f);
            fd_y.SetValue(items[i], -10f);
            fd_z.SetValue(items[i], -10f);
            fd_w.SetValue(items[i], -10f);
        }

        return sum;
    }

    [Benchmark]
    public double FluxioWithoutCache()
    {
        double sum = 0;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            Type t = vs[i].GetType();

            FluxSearchSpace space = new FluxSearchSpace(3, 4);

            FluxRuntimeFieldDesc fd_x = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space);
            FluxRuntimeFieldDesc fd_y = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space);
            FluxRuntimeFieldDesc fd_z = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space);
            FluxRuntimeFieldDesc fd_w = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space);

            sum += fd_x.FieldAccessor.Value<float>(items[i])!;
            sum += fd_y.FieldAccessor.Value<float>(items[i])!;
            sum += fd_z.FieldAccessor.Value<float>(items[i])!;
            sum += fd_w.FieldAccessor.Value<float>(items[i])!;

            fd_x.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_y.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_z.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_w.FieldAccessor.Value<float>(items[i]) = -10f;
        }

        return sum;
    }

    [Benchmark]
    public double Reflection()
    {
        double sum = 0;

        var tuple = cached_FieldInfo;
        FieldInfo fd_x = tuple.Item1;
        FieldInfo fd_y = tuple.Item2;
        FieldInfo fd_z = tuple.Item3;
        FieldInfo fd_w = tuple.Item4;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            sum += (float)fd_x.GetValue(items[i])!;
            sum += (float)fd_y.GetValue(items[i])!;
            sum += (float)fd_z.GetValue(items[i])!;
            sum += (float)fd_w.GetValue(items[i])!;

            fd_x.SetValue(items[i], -10f);
            fd_y.SetValue(items[i], -10f);
            fd_z.SetValue(items[i], -10f);
            fd_w.SetValue(items[i], -10f);
        }

        return sum;
    }

    [Benchmark]
    public double Fluxio()
    {
        double sum = 0;

        var tuple = cached_FieldDesc;
        FluxRuntimeFieldDesc fd_x = tuple.Item1;
        FluxRuntimeFieldDesc fd_y = tuple.Item2;
        FluxRuntimeFieldDesc fd_z = tuple.Item3;
        FluxRuntimeFieldDesc fd_w = tuple.Item4;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            sum += fd_x.FieldAccessor.Value<float>(items[i])!;
            sum += fd_y.FieldAccessor.Value<float>(items[i])!;
            sum += fd_z.FieldAccessor.Value<float>(items[i])!;
            sum += fd_w.FieldAccessor.Value<float>(items[i])!;

            fd_x.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_y.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_z.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_w.FieldAccessor.Value<float>(items[i]) = -10f;
        }

        return sum;
    }
}
