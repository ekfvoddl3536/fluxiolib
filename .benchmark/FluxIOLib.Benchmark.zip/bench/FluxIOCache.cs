﻿
using fluxiolib;

internal static class FluxIOCache
{
    public static readonly UnsafeFieldAccessor fd_x, fd_y, fd_z, fd_w;

    static FluxIOCache()
    {
        var t = typeof(FooLast);

        FluxSearchSpace space = new FluxSearchSpace(3, 4);

        fd_x = FluxTool.GetInstanceField(t, "vec4_x"u8, ProtFlags.Family, TypeFlags.R4, space).FieldAccessor;
        fd_y = FluxTool.GetInstanceField(t, "vec4_y"u8, ProtFlags.Family, TypeFlags.R4, space).FieldAccessor;
        fd_z = FluxTool.GetInstanceField(t, "vec4_z"u8, ProtFlags.Family, TypeFlags.R4, space).FieldAccessor;
        fd_w = FluxTool.GetInstanceField(t, "vec4_w"u8, ProtFlags.Family, TypeFlags.R4, space).FieldAccessor;
    }

    public static void Init()
    {
        int offset =
            fd_x.Offset |
            fd_y.Offset |
            fd_z.Offset |
            fd_w.Offset;

        if (offset < 0)
            throw new InvalidOperationException("Field not found");
    }
}