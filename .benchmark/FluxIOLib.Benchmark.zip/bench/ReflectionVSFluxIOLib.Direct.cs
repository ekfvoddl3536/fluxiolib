﻿using BenchmarkDotNet.Attributes;

partial class ReflectionVSFluxIOLib
{
    [Benchmark(Description = "Direct")]
    public double ADirect()
    {
        double sum = 0;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            sum += (float)items[i].V4x;
            sum += (float)items[i].V4y;
            sum += (float)items[i].V4z;
            sum += (float)items[i].V4w;

            items[i].V4x = -10f;
            items[i].V4y = -10f;
            items[i].V4z = -10f;
            items[i].V4w = -10f;
        }

        return sum;
    }
}
