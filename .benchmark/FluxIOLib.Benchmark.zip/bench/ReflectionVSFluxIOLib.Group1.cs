﻿using BenchmarkDotNet.Attributes;
using fluxiolib;
using System.Reflection;

partial class ReflectionVSFluxIOLib
{
    [Benchmark(Description = "Reflection(w/o cache)")]
    public double BReflectionWithoutCache()
    {
        const BindingFlags FLAGS = BindingFlags.NonPublic | BindingFlags.Instance;

        double sum = 0;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            Type t = vs[i].GetType();

            FieldInfo fd_x = t.GetField("vec4_x", FLAGS)!;
            FieldInfo fd_y = t.GetField("vec4_y", FLAGS)!;
            FieldInfo fd_z = t.GetField("vec4_z", FLAGS)!;
            FieldInfo fd_w = t.GetField("vec4_w", FLAGS)!;

            sum += (float)fd_x.GetValue(items[i])!;
            sum += (float)fd_y.GetValue(items[i])!;
            sum += (float)fd_z.GetValue(items[i])!;
            sum += (float)fd_w.GetValue(items[i])!;

            fd_x.SetValue(items[i], -10f);
            fd_y.SetValue(items[i], -10f);
            fd_z.SetValue(items[i], -10f);
            fd_w.SetValue(items[i], -10f);
        }

        return sum;
    }

    [Benchmark(Description = "FluxIO(w/o cache)")]
    public double CFluxioWithoutCache()
    {
        double sum = 0;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            Type t = vs[i].GetType();

            FluxSearchSpace space = new FluxSearchSpace(3, 4);

            FluxRuntimeFieldDesc fd_x = FluxTool.GetInstanceField(t, "vec4_x"u8, ProtFlags.Family, TypeFlags.R4, space);
            FluxRuntimeFieldDesc fd_y = FluxTool.GetInstanceField(t, "vec4_y"u8, ProtFlags.Family, TypeFlags.R4, space);
            FluxRuntimeFieldDesc fd_z = FluxTool.GetInstanceField(t, "vec4_z"u8, ProtFlags.Family, TypeFlags.R4, space);
            FluxRuntimeFieldDesc fd_w = FluxTool.GetInstanceField(t, "vec4_w"u8, ProtFlags.Family, TypeFlags.R4, space);

            sum += fd_x.FieldAccessor.Value<float>(items[i])!;
            sum += fd_y.FieldAccessor.Value<float>(items[i])!;
            sum += fd_z.FieldAccessor.Value<float>(items[i])!;
            sum += fd_w.FieldAccessor.Value<float>(items[i])!;

            fd_x.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_y.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_z.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_w.FieldAccessor.Value<float>(items[i]) = -10f;
        }

        return sum;
    }
}