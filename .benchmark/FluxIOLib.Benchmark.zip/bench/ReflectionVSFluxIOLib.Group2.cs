﻿using BenchmarkDotNet.Attributes;
using System.Reflection;
using System.Runtime.CompilerServices;

partial class ReflectionVSFluxIOLib
{
    [Benchmark(Description = "Reflection(w/ cache +tuning)")]
    public double DReflection()
    {
        double sum = 0;

        FieldInfo fd_x = ReflectionCache.fd_x;
        FieldInfo fd_y = ReflectionCache.fd_y;
        FieldInfo fd_z = ReflectionCache.fd_z;
        FieldInfo fd_w = ReflectionCache.fd_w;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            sum += (float)fd_x.GetValue(items[i])!;
            sum += (float)fd_y.GetValue(items[i])!;
            sum += (float)fd_z.GetValue(items[i])!;
            sum += (float)fd_w.GetValue(items[i])!;

            fd_x.SetValue(items[i], -10f);
            fd_y.SetValue(items[i], -10f);
            fd_z.SetValue(items[i], -10f);
            fd_w.SetValue(items[i], -10f);
        }

        return sum;
    }

    [Benchmark(Description = "Reflection(w/ cache +tuning +noBoxUnbox)")]
    public double EReflectionWithoutBoxUnbox()
    {
        double sum = 0;

        FieldInfo fd_x = ReflectionCache.fd_x;
        FieldInfo fd_y = ReflectionCache.fd_y;
        FieldInfo fd_z = ReflectionCache.fd_z;
        FieldInfo fd_w = ReflectionCache.fd_w;

        object v = -10f;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            sum += Unsafe.As<RawObject>(fd_x.GetValue(items[i])!).Value;
            sum += Unsafe.As<RawObject>(fd_y.GetValue(items[i])!).Value;
            sum += Unsafe.As<RawObject>(fd_z.GetValue(items[i])!).Value;
            sum += Unsafe.As<RawObject>(fd_w.GetValue(items[i])!).Value;

            fd_x.SetValue(items[i], v);
            fd_y.SetValue(items[i], v);
            fd_z.SetValue(items[i], v);
            fd_w.SetValue(items[i], v);
        }

        return sum;
    }
}