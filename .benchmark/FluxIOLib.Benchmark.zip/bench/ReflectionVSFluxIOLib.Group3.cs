﻿using BenchmarkDotNet.Attributes;
using fluxiolib;
using System.Reflection;

partial class ReflectionVSFluxIOLib
{
    [Benchmark(Description = "FluxIO(w/o name cmp)")]
    public double FFluxioWithoutStrCmp()
    {
        double sum = 0;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            Type t = vs[i].GetType();

            FluxSearchSpace space1 = new FluxSearchSpace(3, 1);
            FluxSearchSpace space2 = new FluxSearchSpace(4, 1);
            FluxSearchSpace space3 = new FluxSearchSpace(5, 1);
            FluxSearchSpace space4 = new FluxSearchSpace(6, 1);

            FluxRuntimeFieldDesc fd_x = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space1);
            FluxRuntimeFieldDesc fd_y = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space2);
            FluxRuntimeFieldDesc fd_z = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space3);
            FluxRuntimeFieldDesc fd_w = FluxTool.GetInstanceField(t, SStringUtf8.AnyAccept, ProtFlags.Family, TypeFlags.R4, space4);

            sum += fd_x.FieldAccessor.Value<float>(items[i])!;
            sum += fd_y.FieldAccessor.Value<float>(items[i])!;
            sum += fd_z.FieldAccessor.Value<float>(items[i])!;
            sum += fd_w.FieldAccessor.Value<float>(items[i])!;

            fd_x.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_y.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_z.FieldAccessor.Value<float>(items[i]) = -10f;
            fd_w.FieldAccessor.Value<float>(items[i]) = -10f;
        }

        return sum;
    }

    [Benchmark(Description = "FluxIO(w/ reflection)")]
    public double FFluxioWithReflection()
    {
        const BindingFlags FLAGS = BindingFlags.NonPublic | BindingFlags.Instance;

        double sum = 0;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            Type t = vs[i].GetType();

            FieldInfo Tfd_x = t.GetField("vec4_x", FLAGS)!;
            FieldInfo Tfd_y = t.GetField("vec4_y", FLAGS)!;
            FieldInfo Tfd_z = t.GetField("vec4_z", FLAGS)!;
            FieldInfo Tfd_w = t.GetField("vec4_w", FLAGS)!;

            UnsafeFieldAccessor fd_x = FluxTool.GetFieldAccessor(Tfd_x.FieldHandle);
            UnsafeFieldAccessor fd_y = FluxTool.GetFieldAccessor(Tfd_y.FieldHandle);
            UnsafeFieldAccessor fd_z = FluxTool.GetFieldAccessor(Tfd_z.FieldHandle);
            UnsafeFieldAccessor fd_w = FluxTool.GetFieldAccessor(Tfd_w.FieldHandle);

            sum += fd_x.Value<float>(items[i])!;
            sum += fd_y.Value<float>(items[i])!;
            sum += fd_z.Value<float>(items[i])!;
            sum += fd_w.Value<float>(items[i])!;

            fd_x.Value<float>(items[i]) = -10f;
            fd_y.Value<float>(items[i]) = -10f;
            fd_z.Value<float>(items[i]) = -10f;
            fd_w.Value<float>(items[i]) = -10f;
        }

        return sum;
    }

    [Benchmark(Description = "FluxIO(w/ cache)")]
    public double GFluxio()
    {
        double sum = 0;

        UnsafeFieldAccessor fd_x = FluxIOCache.fd_x;
        UnsafeFieldAccessor fd_y = FluxIOCache.fd_y;
        UnsafeFieldAccessor fd_z = FluxIOCache.fd_z;
        UnsafeFieldAccessor fd_w = FluxIOCache.fd_w;

        var vs = items;
        for (int i = 0; i < vs.Length; ++i)
        {
            sum += fd_x.Value<float>(items[i])!;
            sum += fd_y.Value<float>(items[i])!;
            sum += fd_z.Value<float>(items[i])!;
            sum += fd_w.Value<float>(items[i])!;

            fd_x.Value<float>(items[i]) = -10f;
            fd_y.Value<float>(items[i]) = -10f;
            fd_z.Value<float>(items[i]) = -10f;
            fd_w.Value<float>(items[i]) = -10f;
        }

        return sum;
    }
}
