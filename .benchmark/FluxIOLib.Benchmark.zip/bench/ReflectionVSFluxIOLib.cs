﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Jobs;

[SimpleJob(RuntimeMoniker.Net80)]
[MarkdownExporter]
public partial class ReflectionVSFluxIOLib
{
    private FooRoot[] items = [];

    [Params(1, 10, 100, 1_000)]
    public int N;

    [GlobalSetup]
    public void Setup()
    {
        items = new FooRoot[N];

        var rand = new Random();
        for (int i = 0; i < items.Length; ++i)
        {
            int v = rand.Next(0, 300);
            items[i] =
                v >= 200
                ? new FooRoot()
                : v >= 100
                ? new FooMid()
                : new FooLast();

            items[i].Rand();
        }

        ReflectionCache.Init();
        FluxIOCache.Init();
    }
}
