﻿using System.Runtime.CompilerServices;

unsafe class FooRoot
{
    public int x;
    public int y;
    public int z;

    protected float vec4_x;
    protected float vec4_y;
    protected float vec4_z;
    protected float vec4_w;

    private string name;
    private void* pointer;

    private delegate*<int, int, int> functionPointer;

    public void Rand()
    {
        vec4_x = 10;
        vec4_y = 10;
        vec4_z = 10;
        vec4_w = 10;
    }

    public ref float V4x
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining | MethodImplOptions.AggressiveOptimization)]
        get => ref vec4_x;
    }

    public ref float V4y
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining | MethodImplOptions.AggressiveOptimization)]
        get => ref vec4_y;
    }

    public ref float V4z
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining | MethodImplOptions.AggressiveOptimization)]
        get => ref vec4_z;
    }

    public ref float V4w
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining | MethodImplOptions.AggressiveOptimization)]
        get => ref vec4_w;
    }
}

unsafe class FooMid : FooRoot
{
    public new long x;
    public new long y;
    public new long z;

    private string name;

    public FooMid next;
    public FooMid prev;
}

unsafe class FooLast : FooMid
{
    internal object myObject;
    internal byte[] myBuffer;

    protected void* pointer2;
}

class RawObject
{
    public float Value;
}