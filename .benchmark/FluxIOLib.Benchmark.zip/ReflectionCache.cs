﻿using System.Reflection;
using System.Runtime.CompilerServices;

internal static class ReflectionCache
{
    public static readonly FieldInfo fd_x, fd_y, fd_z, fd_w;

    static ReflectionCache()
    {
        const BindingFlags FLAGS = BindingFlags.NonPublic | BindingFlags.Instance;

        Type t = typeof(FooRoot);

        fd_x = t.GetField("vec4_x", FLAGS)!;
        fd_y = t.GetField("vec4_y", FLAGS)!;
        fd_z = t.GetField("vec4_z", FLAGS)!;
        fd_w = t.GetField("vec4_w", FLAGS)!;
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    public static void Init()
    {
        bool v =
            fd_x == null |
            fd_y == null |
            fd_z == null |
            fd_w == null;

        if (v)
            throw new InvalidOperationException("Field not found");
    }
}